  ======================================
       Download do site ActiveDelphi:                    
				              		
       http://www.activedelphi.com.br/              
				             
       Componentes, Apostilas, Dicas, 	             	
       Fontes de Sistemas, F�rum, Not�cias          	
				             	
  ======================================

