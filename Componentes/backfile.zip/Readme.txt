TBackup for Delphi3
--------------------
Copyright 1998 Easycash Software / Alexander Halser
Internet homepage: http://www.easycash.co.at


Refer to the help file BACKUP.HLP for more information.